
### Exercice 1 :

Créez une fonction qui prend en entrée l'âge d'une personne et affiche "Majeur" si l'âge est supérieur ou égal à 18, sinon affichez "Mineur".

---
### Exercice 2 :
Affichez les nombres pairs de 1 à 20 en utilisant une boucle for.

---
### Exercice 3 :

Demandez à l'utilisateur de deviner un nombre entre 1 et 100. Utilisez une boucle while pour permettre à l'utilisateur de saisir des nombres jusqu'à ce qu'il devine correctement.

---
### Exercice 4 :

Écrivez une fonction qui prend en entrée un mois (1 pour janvier, 2 pour février, etc.) et retourne le nombre de jours dans ce mois. Assurez-vous de gérer correctement le cas de février pour les années bissextiles (29 jours) et non bissextiles (28 jours).